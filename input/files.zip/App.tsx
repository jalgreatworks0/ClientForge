import LoginPage from './components/LoginPage';
import './index.css';

function App() {
  return <LoginPage />;
}

export default App;
